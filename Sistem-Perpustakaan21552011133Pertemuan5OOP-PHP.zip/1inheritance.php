<?php
// kelas utama
class LibraryItem {
    protected $judul;
    protected $available = true;

    public function __construct($judul) {
        $this->judul = $judul;
    }

    public function getTitle() {
        return $this->judul;
    }

    public function isAvailable() {
        return $this->available;
    }

    public function borrow() {
        if ($this->available) {
            $this->available = false;
            echo "Item '{$this->judul}' telah dipinjam.\n";
        } else {
            echo "Maaf, '{$this->judul}' sudah tidak tersedia.\n";
        }
    }

    public function returnItem() {
        if (!$this->available) {
            $this->available = true;
            echo "Item '{$this->judul}' telah dikembalikan.\n";
        } else {
            echo "Error! '{$this->judul}' sudah tersedia.\n";
        }
    }

    public function displayAvailability() {
        $status = $this->available ? "tersedia" : "tidak tersedia";
        echo "Item '{$this->judul}' is $status.\n";
    }
}

class Book extends LibraryItem {
    private $author;

    public function __construct($judul, $author) {
        parent::__construct($judul);
        $this->author = $author;
    }

    public function getAuthor() {
        return $this->author;
    }

    public function displayDetails() {
        echo "Judul: {$this->judul}\n";
        echo "Penulis: {$this->author}\n";
        $this->displayAvailability();
    }
}

class Library {
    private $items = [];

    public function addItem(LibraryItem $item) {
        $this->items[] = $item;
        echo "Item '{$item->getTitle()}' telah ditambahkan kedalam library.\n";
    }

    public function listAvailableBooks() {
        echo "Buku yang tresedia:\n";
        foreach ($this->items as $item) {
            if ($item instanceof Book && $item->isAvailable()) {
                echo "- {$item->getTitle()} by {$item->getAuthor()}\n";
            }
        }
    }
}

// Contoh penggunaan
$library = new Library();

// Menambahkan buku
$book1 = new Book("Habis Gelap Terbitlah Terang", "J.H. Abendanon");
$book2 = new Book("Anak Semua bangsa", "Preamoedya Ananta Toer");
$library->addItem($book1);
$library->addItem($book2);

// Meminjam buku
$book1->borrow();

// Menampilkan daftar buku yang tersedia
$library->listAvailableBooks();

// Mengembalikan buku
$book1->returnItem();
