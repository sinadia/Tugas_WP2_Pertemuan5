<?php

class LibraryItem {
    protected $judul;
    protected static $availableItems = [];

    public function __construct($judul) {
        $this->judul = $judul;
        self::$availableItems[$judul] = true;
    }

    public function getTitle() {
        return $this->judul;
    }

    public static function isAvailable($judul) {
        return isset(self::$availableItems[$judul]) && self::$availableItems[$judul];
    }

    public static function borrow($judul) {
        if (self::isAvailable($judul)) {
            self::$availableItems[$judul] = false;
            echo "Item '{$judul}' telah dipinjam.\n";
        } else {
            echo "Sorry, '{$judul}' sudah tidak tersedia.\n";
        }
    }

    public static function returnItem($judul) {
        if (!self::isAvailable($judul)) {
            self::$availableItems[$judul] = true;
            echo "Item '{$judul}' telah dikembalikan.\n";
        } else {
            echo "Error! '{$judul}' telah tersedia.\n";
        }
    }

    public static function displayAvailability($judul) {
        $status = self::isAvailable($judul) ? "available" : "not available";
        echo "Item '{$judul}' is $status.\n";
    }
}

class Book extends LibraryItem {
    private $author;

    public function __construct($judul, $author) {
        parent::__construct($judul);
        $this->author = $author;
    }

    public function getAuthor() {
        return $this->author;
    }

    public function displayDetails() {
        echo "Book Title: {$this->getTitle()}\n";
        echo "Author: {$this->author}\n";
        self::displayAvailability($this->getTitle());
    }
}

class Library {
    private static $items = [];

    public static function addItem(LibraryItem $item) {
        self::$items[] = $item;
        echo "Item '{$item->getTitle()}' telah ditambahkan kedalam library.\n";
    }

    public static function listAvailableBooks() {
        echo "Buku yang terssedia:\n";
        foreach (self::$items as $item) {
            if ($item instanceof Book && LibraryItem::isAvailable($item->getTitle())) {
                echo "- {$item->getTitle()} by {$item->getAuthor()}\n";
            }
        }
    }
}

// Contoh penggunaan
$library = new Library();

// Menambahkan buku
$book1 = new Book("Habis Gelap Terbitlah Terang", "J.H. Abendanon");
$book2 = new Book("Anak Semua bangsa", "Preamoedya Ananta Toer");
$library->addItem($book1);
$library->addItem($book2);

// Meminjam buku
LibraryItem::borrow("Habis gelap terbitlah terang");

// Menampilkan daftar buku yang tersedia
Library::listAvailableBooks();

// Mengembalikan buku
LibraryItem::returnItem("Habis Gelap Terbitlah Terang");

?>
