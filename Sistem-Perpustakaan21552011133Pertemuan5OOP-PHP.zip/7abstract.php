<?php

abstract class LibraryItem {
    protected $judul;
    protected $available = true;

    public function __construct($judul) {
        $this->judul = $judul;
    }

    public function getTitle() {
        return $this->judul;
    }

    public function isAvailable() {
        return $this->available;
    }

    abstract public function displayDetails();

    public function borrow() {
        if ($this->available) {
            $this->available = false;
            echo "Item '{$this->judul}' telah dipinjam.\n";
        } else {
            echo "Sorry, '{$this->judul}' sudah tidak tersedia.\n";
        }
    }

    public function returnItem() {
        if (!$this->available) {
            $this->available = true;
            echo "Item '{$this->judul}' telah dikembalikan.\n";
        } else {
            echo "Error! '{$this->judul}' telah tersedia.\n";
        }
    }

    public function displayAvailability() {
        $status = $this->available ? "available" : "not available";
        echo "Item '{$this->judul}' is $status.\n";
    }
}

class Book extends LibraryItem {
    private $penulis;

    public function __construct($judul, $penulis) {
        parent::__construct($judul);
        $this->penulis = $penulis;
    }

    public function getAuthor() {
        return $this->penulis;
    }

    public function displayDetails() {
        echo "Judul: {$this->getTitle()}\n";
        echo "Penulis: {$this->penulis}\n";
        $this->displayAvailability();
    }
}

class Magazine extends LibraryItem {
    private $issue;

    public function __construct($judul, $issue) {
        parent::__construct($judul);
        $this->issue = $issue;
    }

    public function getIssue() {
        return $this->issue;
    }

    public function displayDetails() {
        echo "Judul Majalah: {$this->getTitle()}\n";
        echo "Issue: {$this->issue}\n";
        $this->displayAvailability();
    }
}

class Library {
    private $items = [];

    public function addItem(LibraryItem $item) {
        $this->items[] = $item;
        echo "Item '{$item->getTitle()}' telah ditambahakan kedalam library.\n";
    }

    public function listAvailableItems() {
        echo "Available Items:\n";
        foreach ($this->items as $item) {
            if ($item->isAvailable()) {
                $item->displayDetails();
            }
        }
    }
}

// Contoh penggunaan
$library = new Library();

// Menambahkan buku dan majalah
$book1 = new Book("Habis Gelap Terbitlah Terang", "J.H. Abendanon");
$book2 = new Book("Anak Semua bangsa", "Preamoedya Ananta Toer");
$library->addItem($book1);
$library->addItem($book2);

// Meminjam buku
$book1->borrow();

// Menampilkan daftar item yang tersedia
$library->listAvailableItems();

// Mengembalikan buku
$book1->returnItem();
